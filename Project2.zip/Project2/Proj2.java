public class Proj2{
    public static void main(String args[])
	{
		Table t = new Table();
		t.setVisible(true);

	
	}
}

