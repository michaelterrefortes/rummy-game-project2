public interface PileInterface{

    public void MyStack();

    public void push(Card card);

    public Card pop();

    public Card top();

    public boolean isEmpty();

    
}